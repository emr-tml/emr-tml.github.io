//
//  nonce.h
//  Meridian
//
//  Created by Ben on 29/07/2018.
//

#ifndef nonce_h
#define nonce_h

int set_boot_nonce(const char *gen);
const char *copy_boot_nonce(void);

#endif /* nonce_h */
