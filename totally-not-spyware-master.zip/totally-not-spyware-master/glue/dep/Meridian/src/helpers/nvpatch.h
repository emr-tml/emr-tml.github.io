//
//  nvpatch.h
//  Meridian
//
//  Created by Ben Sparkes on 11/05/2018.
//  Copyright © 2018 Ben Sparkes. All rights reserved.
//

#ifndef nvpatch_h
#define nvpatch_h

int nvpatch(const char *target);

#endif /* nvpatch_h */
